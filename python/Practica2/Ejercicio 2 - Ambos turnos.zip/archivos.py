#!/usr/bin/env python3

# Crear dentro del archivo "archivos.py" la funcion leer_archivos() que genere un diccionario en donde cada clave corresponda al nombre de un subdirectorio de "imagenes", y su valor sea una lista con los nombres de los archivos. 
#Por ejemplo, para la siguiente estructura de directorios:

#./imagenes/dir06/Excepcion5.png
#./imagenes/dir06/Excepcion9.png
#./imagenes/dir07/Excepcion6.png
#./imagenes/dir02/school.jpg

#Devuelva el siguiente diccionario:

#{'dir06': ['Excepcion5.png', 'Excepcion9.png'], 'dir07': ['Excepcion6.png'], 'dir02': ['school.jpg']}

def leer_archivos():
  print('leer_archivos(): Modificar esta funcion para generar la estructura devuelta (variable imagenes) leyendo todos los subdirectorios de "imagenes/" dinamicamente')
  
  imagenes = {'dir06': ['Excepcion5.png', 'Excepcion9.png'], 'dir07': ['Excepcion6.png'], 'dir02': ['school.jpg']}

  return imagenes

